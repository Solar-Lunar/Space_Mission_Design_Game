# GAME DESIGN DOCUMENT — Mission Architect: Beyond Earth

## 1. High concept
A third-person, mission-based, single-player 3D space adventure where the player walks through a space agency hangar, engineers an Earth-observation satellite, launches it into orbit, pilots the satellite, manages scarce resources, solves emergencies, and returns science data. Engineering is presented as **action with consequences**, rather than a quiz or static dashboard.

**Inspiration (genre only):** hands-on engineering from Kerbal Space Program, accessible pilot movement from spaceflight games, and mission structure from adventure games. All creative content must be original.

**Challenge alignment:** explicit objective, vehicle/instrument decisions, spacecraft mass and power, data handling, launch capacity, orbital effects, finite budget and success/failure explanations. The game prioritizes integrated trade-offs over graphical spectacle.

**Audience:** Beginner-to-intermediate learners and players aged 12+. Player can learn by trial and error. Desktop PC first; web build second. Accessibility: large UI, color-independent failure icons, configurable sensitivity, remappable keys and tutorials in later milestones.

## 2. Pillars
1. **Play, don't fill forms:** Walk, interact, build, launch, steer and recover.
2. **Every part has trade-offs:** More science instruments cost mass, power, budget, storage and downlink.
3. **Failure teaches:** Show exact subsystem reason and a viable design alternative.
4. **Scientifically transparent:** Flag simplifications and separate realistic equations from fictional balance values.
5. **Repeatability:** Retry mission with a different loadout; compare delivered science and score.

## 3. Core gameplay loop
```
Accept objective → explore hangar → configure spacecraft
→ engineering validation → launch → orbital deployment
→ collect science + conserve power + schedule downlink
→ survive events → deliver science → score and debrief
→ upgrade/iterate → next mission
```

## 4. Narrative, avatar and setting
Player is the new Flight Systems Engineer at fictional **Horizon Space Lab**. Mentor/dispatcher MAY be an AI-flavored in-world flight computer, but simulation authority remains deterministic. The first mission **Earth Climate Sentinel** requires delivering 18 GB of observation data while retaining spacecraft operation. Project is unofficial and is not endorsed by NASA.

## 5. Camera, control and interaction
| Mode | Movement | Interaction |
|---|---|---|
| Hangar | WASD, sprint Shift, jump Space | E near terminal, buttons optional |
| Builder | UI option selectors | Validate design / launch |
| Launch | Cinematic orbit insertion in MVP | Future: throttle, pitch, stage separation |
| Orbit | W/S altitude, A/D lateral steering | I science on/off, T transmit on ground pass |
| Debrief | UI only | Retry / edit design (future) |

Longer-term player features: third-person shoulder camera, gamepad, EVA magnetic boots, repair mini-game, collisions, contextual interaction labels and a pause/inventory menu.

## 6. Mission stages

### 6.1 Hangar (player controller)
Spatial scene with astronaut, floor, launch pad, construction terminal, launcher. Walking to terminal launches engineering configuration. Needs ambience and interaction hints. Later add component pickups, drag/placement, tools and in-world instructional holograms.

### 6.2 Build phase (engineering game)
Players choose spacecraft bus, battery, solar, antenna, payload, computer and launcher. MVP uses camera/solar/antenna/launcher plus a fixed spacecraft bus; future modules become selectable. Real-time numbers show launch margin, average and peak power, cost and data rate.

**Illustrative first-mission configuration** (not real rocket catalog):
- Base bus: 65 kg, 30 W, 30 M credits.
- Camera basic: 30 kg, 22 W, 12 M; advanced: 82 kg, 85 W, 42 M.
- Solar small: 23 kg, 85 W generated, 9 M; large: 65 kg, 220 W generated, 23 M.
- Antenna basic: 16 kg, 14 W, 7 M, 2.1 GB / contact action; high gain: 35 kg, 26 W, 18 M, 5.2 GB / action.
- Rocket small payload capacity 185 kg, 25 M; larger 350 kg, 42 M.
- Mission budget 140 M credits.

**Validation:** mass ≤ launch capacity, full-time electrical load ≤ solar rated output (MVP prelaunch approximation), total cost ≤ budget. These must all pass for launch. Next revision validates eclipses using battery capacity and duty cycling rather than simplistic average power.

### 6.3 Launch (cinematic for prototype)
Rocket visibly ascends and the view follows. A staged, physics-assisted launch is the next milestone: pitch/throttle control, gravity, drag, first-stage fuel and stage separation. In the prototype the outcome is determined by prelaunch compatibility, not player steering.

### 6.4 Orbit (flight gameplay)
Ship rendered over Earth. W/S requests altitude adjustments consuming fuel, A/D adjusts lateral position (gamified, not an actual orbital maneuver). Science instrument autonomously produces data when ON. Solar power available in sunlight. Ground pass occurs periodically; player presses T to downlink science while in range. Mission ends in success at 18 GB delivered or incomplete/failure at early debrief or battery depletion.

Physics roadmap:
- **MVP:** circular orbit period uses `T=2π√((R+h)^3/μ)` where h in km.
- **Next:** equatorial/inclined Kepler motion and station contact based on satellite ECEF to station geometry.
- **Later:** J2 perturbation, constrained burns and launch site/orbit trade-offs.

### 6.5 Emergencies
Prototype: energy depletion, fuel consumption, invalid launch configurations. Next: telemetry failure, thermal overload, antenna misalignment, solar panel damage, micrometeoroid event. Each event must support a physical or procedural mitigation, not a random punishment.

### 6.6 Debrief
Status, science delivered, power/fuel remaining, mission clock and score. Explain cause of failure. Future: side-by-side design comparisons and exportable engineering report.

## 7. Scoring and fail states
Starter scoring = clamped sum of delivered data, battery remaining, fuel remaining and success bonus. This is provisional; production scoring should use:
- 35% mission objectives completed,
- 25% scientifically useful delivered observations,
- 20% hardware reliability and spacecraft survival,
- 15% mass/power/budget efficiency,
- 5% emergency response.

Explicit fail conditions: crash/invalid insertion (advanced flight), battery depletion, mission deadline missed, science quota missed. Score must never allow a failed primary mission to rank higher than a genuinely successful mission without transparent weighting.

## 8. Game feel and visual direction
Art: original low-poly/semi-realistic hard science fiction. Dark blue hangar, cyan interactive terminals, amber warnings, high-contrast suit and spacecraft silhouettes. Camera gently tracks astronaut. In orbit, Earth fills background with scale exaggerated visually; rendered assets will be upgraded later in Blender. SFX include boots, UI clicks, launch rumble, comms ping, warnings. Music optional; no copyrighted soundtrack bundled.

## 9. Level progression
- **Mission 1: Earth Climate Sentinel** — basic LEO, one instrument, solar/battery, regular contact passes.
- **Mission 2: Polar Mapping** — high inclination orbit, ground coverage and downlink frequency trade-offs.
- **Mission 3: Lunar Reconnaissance** — transfer delta-v and deep-space communications.
- **Mission 4: Mars Relay** — travel time, light-delay, limited autonomy and high reliability.

Mission 1 must be enjoyable and complete before extending other scenarios.

## 10. Multiplayer design (post-MVP)
Up to four players in a shared planning room: Flight Director, Systems Engineer, Science Officer, Communications Officer. Synchronize actions via authenticated room state; validate mission configuration authoritatively. Multiplayer can be split into synchronous engineering/planning and asynchronous flight roles. Avoid four independent clients calculating different orbital states.

## 11. Technical design
- Godot 4.x + GDScript 2.0; 3D rendering, scene nodes, input system and finite-state machine.
- Scene-based composition; character controller uses CharacterBody3D with move_and_slide.
- Data layer: Resources/JSON for mission catalog and equipment. No hardcoded catalog in final production.
- Event bus: MissionState signals for resources and phase transitions.
- Pure calculation layer for engineering rules; unit-tested independently of UI.
- Backend optional for MVP. Supabase or other server only for accounts, leaderboards and shared rooms.

### Production scene tree
```
Main (Node)
├── GameState (autoload)
├── MissionDirector (Node)
├── UI (CanvasLayer)
│   ├── HUD / ObjectiveTracker
│   ├── EquipmentBuilder
│   ├── FlightTelemetry
│   └── Debrief
└── LevelRoot (Node3D)
    ├── Hangar (PackedScene)
    │   ├── Player (CharacterBody3D)
    │   │   ├── CollisionShape3D
    │   │   ├── CharacterVisual
    │   │   └── CameraRig
    │   ├── ComponentStations
    │   └── LaunchPad
    ├── Launch (PackedScene)
    └── Orbit (PackedScene)
        ├── Earth
        ├── Satellite
        ├── OrbitPath
        ├── GroundStations
        └── MissionCamera
```
Prototype uses one main scene and procedural nodes for ease of initial import. **Production must split each module into scenes**, and replace static GUI layout with responsive containers.

## 12. Scientific fidelity roadmap
- clearly label game balance vs sourced aerospace specifications;
- orbital period and relative altitude right to physical units;
- meaningful battery state of charge, eclipse cycles, power scheduling and instrument duty cycle;
- downlink constrained by line of sight, available contact time, link bitrate and onboard storage;
- rocket performance dependent on destination orbit, rather than one constant payload capacity;
- craft mass includes dry and wet mass, margins and propellant;
- orbital burns consume propellant via rocket equation, and change orbital elements;
- record assumptions/sources inside `docs/scientific_sources.md`.

## 13. Success criteria
MVP is a game when an ordinary player can control an astronaut, build a materially different spacecraft, see its representation, launch, steer the satellite in a rendered world, collect and transmit science, fail/retry, and understand why. No gameplay should require an account or API key. A good judged demonstration should take 3–5 minutes and prove cause/effect via two loadouts.

## 14. Scope guardrails
**In the starter:** single hangar, basic astronaut, configuration terminal, launch animation, orbital controls, power/science/downlink and debrief. **Not yet:** multiplayer, asset-quality visuals, actual orbital maneuver physics, EVA repair, realistic rocket piloting, save slots, authentic NASA textures, narrated tutorial or full three-dimensional spacecraft drag-and-drop.

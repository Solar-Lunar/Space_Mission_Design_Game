# Scene map and scripts

### Current runnable starter
`main.tscn`: Node3D with `game.gd` script. Creates world, astronaut, 3D spaceship, rocket, Earth, all GUI and mission state at runtime. `player.gd` is bound to a CharacterBody3D at runtime.

State transitions:

```
HANGAR ──E/Builder button──> BUILD ──valid launch──> LAUNCH
   ▲                          │                         │
   │                          └─invalid→ remain BUILD    │ after 9s
   │                                                     ▼
   └────────────────── RETRY <── REPORT <── success / end / battery fail
                                                  ▲        │
                                                  └── ORBIT ┘
```

Scene extraction plan:

- `scenes/hangar/hangar.tscn`: static environment, terminals, pad and world props.
- `scenes/player/astronaut.tscn`: CharacterBody3D, visual, collision, camera rig.
- `scenes/builder/builder.tscn`: drag/drop, snap nodes, UI, equipment catalog.
- `scenes/launch/launch.tscn`: rocket, stage controllers, environment, chase camera.
- `scenes/orbit/orbit.tscn`: Earth, orbital track, spacecraft, station locations.
- `scenes/ui/hud.tscn`: objective/telemetry overlay.
- `scenes/ui/debrief.tscn`: mission report.
- `autoload/mission_state.gd`: global typed mission configuration, mission progress, serialized save and events.
- `simulation/`: pure numeric solvers (not dependent on scene tree).

Data contracts: `MissionDefinition`, `ComponentSpec`, `DesignConfiguration`, `SimulationStep`, `TelemetryEvent`, `MissionScore`. Keep physics values in SI units internally, convert to human-readable UI units at boundaries.

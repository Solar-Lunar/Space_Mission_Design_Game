# Implementation backlog — dependency-aware

## P0: Importable vertical slice (included as starter code)
- [x] Godot 4 project + procedural 3D hangar
- [x] Astronaut CharacterBody3D + WASD, sprint, jump
- [x] Build terminal + four choices
- [x] Mass/power/cost validation and launch gating
- [x] 9-second launch cinematic
- [x] Rendered Earth/satellite + orbital movement
- [x] Solar/eclipses (approx), battery, observation storage and contact window
- [x] Downlink command and mission debrief/retry
- [ ] Run game in Godot 4 editor and fix any parser/runtime issues (Godot executable not available in packaging environment)

## P1: Make it feel like a shipped game
- [ ] Mouse-look third-person camera with UI cursor mode
- [ ] Proper camera-relative WASD and collision with hangar props
- [ ] Character/satellite/rocket GLB models, particles, HUD meters, sound and VFX
- [ ] 3D attach points, ghost-preview, snap and undo for actual component construction
- [ ] Save/reload designs and persistent player unlocks
- [ ] Tutorial prompts and objective arrows; pause and settings
- [ ] Keyboard remapping and colorblind accessibility
- [ ] Automated CI: static script lint, Godot headless load, integration smoke

## P2: Physics and engineering redesign
- [ ] Autoload MissionState with typed Resources and signals
- [ ] Break out scripts into engineering_validator.gd, orbit_solver.gd, power_model.gd, link_model.gd and events.gd
- [ ] Battery energy in Wh, time steps in seconds, panels affected by sun/eclipse
- [ ] Ground station line-of-sight and bandwidth x pass duration
- [ ] Launch payload capacity orbit-dependent and fueled mass modeled
- [ ] Orbital inclination, elliptical orbit and target insertion tolerance
- [ ] Playable rocket throttle/pitch/staging/fuel/drag + fail/retry
- [ ] Proper orbital maneuver planning and delta-v for thruster controls
- [ ] Real solar-panel degradation and emergency repair mini-games
- [ ] Science objective / telemetry scoring verified by unit tests

## P3: Content and polished release
- [ ] Mission 2 polar coverage; mission 3 lunar; mission 4 Mars relay
- [ ] 4-player planning room with authoritative synchronization
- [ ] Story, cutscenes, achievements, leaderboard
- [ ] AI tutor (optional) strictly grounded in real event logs
- [ ] Export Windows build and browser-compatible build if performance allows
- [ ] Evidence of sourcing/licensing for NASA datasets and assets
- [ ] Record 3–5 minute gameplay demo + technical walkthrough

## Acceptance tests
1. Character moves and collides with floor; E opens builder within five units.
2. Advanced camera + small solar fails prelaunch power validation.
3. An overweight configuration fails capacity validation.
4. Mass/power/cost-affordable build starts launch animation.
5. Launch transitions to orbit scene in ~9 seconds.
6. Scientific instrument off prevents new data collection.
7. Satellite in eclipse loses charge; sunlight recharges based on supply.
8. Transmit only works when ground_contact is true.
9. Enough transmissions produce success report; early end produces incomplete report.
10. Retry resets position, resources and phase without a restart.

## Suggested developer assignments (4-person team)
- **Gameplay/Player:** movement, orbit controls, tutorial, cinematic.
- **Art/World:** Blender assets, hangar, spaceship, particles, sound.
- **Simulation:** engineering constraints, orbital model, verification.
- **Integration/UI:** mission UX, QA, deployments, documentation, authoritative multiplayer later.

## Practical sprint order
- Sprint 1: Import and play starter; fix project startup; deliver 60-second screencast.
- Sprint 2: Improve astronaut/camera/hangar and spacecraft assembly interactions.
- Sprint 3: Replace cinematic rocket with playable throttle/staging while retaining existing validation.
- Sprint 4: Engineering realism, contact pass scheduler, failure handling and scoring.
- Sprint 5: Art polish, usability, automated tests and packaging.

## Technical debts explicitly accepted in starter
- Single monolithic game.gd, no assets, relative-screen HUD positions.
- Visual orbital scale differs from real space units, orbital angles time-accelerated.
- Fictitious hardware data, simplified resource and contact models.
- Mouse is used for HUD; no mouse-look or controller support.

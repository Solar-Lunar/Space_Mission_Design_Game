extends CharacterBody3D

const SPEED := 6.0
const SPRINT := 10.0
const JUMP_VELOCITY := 5.5

var enabled := true
var gravity := 16.0
var avatar: Node3D

func _ready() -> void:
    avatar = Node3D.new()
    avatar.name = "AstronautAvatar"
    add_child(avatar)
    var white := Color(0.88, 0.93, 1.0)
    var torso := _part(Vector3(0, 1.08, 0), Vector3(0.74, 0.95, 0.42), white)
    torso.name = "Suit"
    _part(Vector3(0, 1.84, 0), Vector3(0.59, 0.59, 0.59), white, true)
    _part(Vector3(0, 1.82, -0.31), Vector3(0.40, 0.27, 0.06), Color(0.08, 0.45, 0.66))
    _part(Vector3(-0.53, 1.10, 0), Vector3(0.28, 0.80, 0.30), white)
    _part(Vector3(0.53, 1.10, 0), Vector3(0.28, 0.80, 0.30), white)
    _part(Vector3(-0.19, 0.40, 0), Vector3(0.31, 0.76, 0.33), white)
    _part(Vector3(0.19, 0.40, 0), Vector3(0.31, 0.76, 0.33), white)
    _part(Vector3(0, 1.10, 0.35), Vector3(0.63, 0.72, 0.27), Color(0.44, 0.51, 0.63))
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.45
    capsule.height = 2.2
    var collision := CollisionShape3D.new()
    collision.shape = capsule
    collision.position.y = 1.1
    add_child(collision)

func _part(pos: Vector3, size: Vector3, color: Color, sphere := false) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    if sphere:
        var mesh := SphereMesh.new()
        mesh.radius = size.x * 0.5
        mesh.height = size.y
        m.mesh = mesh
    else:
        var mesh := BoxMesh.new()
        mesh.size = size
        m.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = 0.25
    mat.roughness = 0.45
    m.material_override = mat
    m.position = pos
    avatar.add_child(m)
    return m

func _physics_process(delta: float) -> void:
    if not enabled:
        return
    if not is_on_floor():
        velocity.y -= gravity * delta
    if Input.is_key_pressed(KEY_SPACE) and is_on_floor():
        velocity.y = JUMP_VELOCITY
    var move := Vector3.ZERO
    if Input.is_key_pressed(KEY_W): move.z -= 1.0
    if Input.is_key_pressed(KEY_S): move.z += 1.0
    if Input.is_key_pressed(KEY_A): move.x -= 1.0
    if Input.is_key_pressed(KEY_D): move.x += 1.0
    move = move.normalized()
    var speed := SPRINT if Input.is_key_pressed(KEY_SHIFT) else SPEED
    velocity.x = move.x * speed
    velocity.z = move.z * speed
    if move.length() > 0.0:
        avatar.rotation.y = atan2(-move.x, -move.z)
    move_and_slide()

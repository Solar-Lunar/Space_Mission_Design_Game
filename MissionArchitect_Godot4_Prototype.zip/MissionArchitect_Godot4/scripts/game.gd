extends Node3D

# Mission Architect starter vertical slice. All meshes are procedural.
# Not an aerospace-grade simulation: time/flight scale and launcher are gamified.

const PlayerScript = preload("res://scripts/player.gd")
const BUDGET := 140.0
const ORBIT_TARGET := 550.0
const MU_EARTH := 398600.4418 # km^3/s^2
const EARTH_RADIUS := 6371.0 # km

var phase := "HANGAR"
var player
var camera: Camera3D
var world: Node3D
var rocket: Node3D
var satellite: Node3D
var earth: MeshInstance3D
var terminal: Node3D
var hud: CanvasLayer
var title_label: Label
var message_label: Label
var stats_label: Label
var actions: VBoxContainer
var build_panel: PanelContainer
var report_panel: PanelContainer
var cam_selector: OptionButton
var solar_selector: OptionButton
var antenna_selector: OptionButton
var rocket_selector: OptionButton
var launch_timer := 0.0
var orbit_elapsed := 0.0
var orbit_angle := 0.0
var lateral_offset := 0.0
var altitude := 550.0
var fuel := 100.0
var battery := 100.0
var storage := 0.0
var delivered := 0.0
var score := 0
var science_on := true
var sunlight := true
var ground_contact := false
var deployed := false
var failure_reason := ""
var mission_time := 0.0
var signal_hint := ""

const CAMERA_DATA := [
    {"name":"Basic camera", "mass":30.0, "power":22.0, "cost":12.0, "science":1.3, "data":1.4},
    {"name":"Advanced camera", "mass":82.0, "power":85.0, "cost":42.0, "science":2.8, "data":3.8}
]
const SOLAR_DATA := [
    {"name":"Small array", "mass":23.0, "power":85.0, "cost":9.0},
    {"name":"Large array", "mass":65.0, "power":220.0, "cost":23.0}
]
const ANTENNA_DATA := [
    {"name":"Basic antenna", "mass":16.0, "power":14.0, "cost":7.0, "link":2.1},
    {"name":"High gain antenna", "mass":35.0, "power":26.0, "cost":18.0, "link":5.2}
]
const ROCKET_DATA := [
    {"name":"Scout launcher", "capacity":185.0, "cost":25.0},
    {"name":"Atlas-class game launcher", "capacity":350.0, "cost":42.0}
]

func _ready() -> void:
    _create_world()
    _create_hangar()
    _create_ui()
    _set_phase("HANGAR")

func _create_world() -> void:
    world = Node3D.new()
    world.name = "World"
    add_child(world)
    var environment := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#071426")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#92afdf")
    env.ambient_light_energy = 0.7
    environment.environment = env
    add_child(environment)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -25, 0)
    sun.light_energy = 1.7
    add_child(sun)
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 70.0
    add_child(camera)

func _material(color: Color, glow := false) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = 0.25
    mat.roughness = 0.55
    if glow:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 1.5
    return mat

func _box(parent: Node3D, name_: String, pos: Vector3, dims: Vector3, color: Color, glow := false) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = name_
    var mesh := BoxMesh.new()
    mesh.size = dims
    node.mesh = mesh
    node.material_override = _material(color, glow)
    node.position = pos
    parent.add_child(node)
    return node

func _sphere(parent: Node3D, name_: String, pos: Vector3, radius: float, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = name_
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 48
    mesh.rings = 24
    node.mesh = mesh
    node.position = pos
    node.material_override = _material(color)
    parent.add_child(node)
    return node

func _create_hangar() -> void:
    _box(world, "HangarFloor", Vector3(0,-0.2,0), Vector3(44,0.4,44), Color("#263344"))
    var floor_body := StaticBody3D.new()
    var shape := CollisionShape3D.new()
    var ground := BoxShape3D.new()
    ground.size = Vector3(44,0.4,44)
    shape.shape = ground
    shape.position.y = -0.2
    floor_body.add_child(shape)
    world.add_child(floor_body)
    for i in range(-4, 5):
        _box(world, "FloorStripe", Vector3(float(i)*4,0.015,0), Vector3(0.07,0.02,38), Color("#38536c"), true)
    for i in [-1,1]:
        _box(world,"Pillar",Vector3(float(i)*18,5,-14),Vector3(1.1,10,1.1),Color("#52647b"))
        _box(world,"Floodlight",Vector3(float(i)*18,8,-14),Vector3(3,0.4,0.6),Color("#68c7f5"), true)
    _box(world,"LaunchPad",Vector3(10,0.12,-9),Vector3(12,0.25,12),Color("#405267"))
    terminal = Node3D.new()
    terminal.position = Vector3(-6,0,-6)
    world.add_child(terminal)
    _box(terminal,"Desk",Vector3(0,0.8,0),Vector3(2.5,1.55,1.0),Color("#3e526a"))
    _box(terminal,"Screen",Vector3(0,2,-0.2),Vector3(2.15,1.3,0.19),Color("#12b9df"),true)
    _box(terminal,"ScreenBack",Vector3(0,2,-0.35),Vector3(2.45,1.6,0.15),Color("#101b2f"))
    rocket = Node3D.new()
    rocket.position = Vector3(10,0.3,-9)
    world.add_child(rocket)
    _create_rocket_geometry(rocket)
    player = CharacterBody3D.new()
    player.set_script(PlayerScript)
    player.position = Vector3(-6,0,3)
    world.add_child(player)
    satellite = Node3D.new()
    satellite.visible = false
    world.add_child(satellite)
    _create_satellite_geometry()
    earth = _sphere(world,"Earth",Vector3.ZERO,16.0,Color("#27669e"))
    earth.visible = false

func _create_rocket_geometry(parent: Node3D) -> void:
    _box(parent,"RocketBody",Vector3(0,4.0,0),Vector3(1.5,7.8,1.5),Color("#e9eef7"))
    _box(parent,"RocketNose",Vector3(0,8.3,0),Vector3(1.1,1.0,1.1),Color("#ed8551"))
    _box(parent,"Engine",Vector3(0,-0.1,0),Vector3(1.15,0.6,1.15),Color("#242c3c"))
    for i in [-1.0,1.0]:
        _box(parent,"Fin",Vector3(i,0.8,0),Vector3(1.8,1.8,0.25),Color("#da7249"))

func _create_satellite_geometry() -> void:
    _box(satellite,"Bus",Vector3.ZERO,Vector3(1.3,1.1,1.5),Color("#a5b1c3"))
    _box(satellite,"LeftPanel",Vector3(-2.0,0,0),Vector3(2.7,0.08,1.8),Color("#194d91"))
    _box(satellite,"RightPanel",Vector3(2.0,0,0),Vector3(2.7,0.08,1.8),Color("#194d91"))
    _box(satellite,"Antenna",Vector3(0,1,0),Vector3(0.15,1.2,0.15),Color("#e3e5e5"))
    _sphere(satellite,"Dish",Vector3(0,1.6,0),0.45,Color("#e3c47a"))

func _create_ui() -> void:
    hud = CanvasLayer.new()
    add_child(hud)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(root)
    var top := PanelContainer.new()
    top.position = Vector2(18,14)
    top.custom_minimum_size = Vector2(620,60)
    root.add_child(top)
    var top_box := VBoxContainer.new()
    top.add_child(top_box)
    title_label = Label.new()
    title_label.add_theme_font_size_override("font_size",23)
    top_box.add_child(title_label)
    message_label = Label.new()
    top_box.add_child(message_label)
    var side := PanelContainer.new()
    side.position = Vector2(18,95)
    side.custom_minimum_size = Vector2(380,125)
    root.add_child(side)
    stats_label = Label.new()
    stats_label.custom_minimum_size = Vector2(370,120)
    side.add_child(stats_label)
    actions = VBoxContainer.new()
    actions.position = Vector2(18,245)
    actions.custom_minimum_size = Vector2(330,0)
    root.add_child(actions)
    build_panel = PanelContainer.new()
    build_panel.position = Vector2(770,65)
    build_panel.custom_minimum_size = Vector2(460,440)
    root.add_child(build_panel)
    var build_box := VBoxContainer.new()
    build_panel.add_child(build_box)
    var build_title := Label.new()
    build_title.text = "SPACECRAFT ASSEMBLY"
    build_title.add_theme_font_size_override("font_size",24)
    build_box.add_child(build_title)
    cam_selector = _selector(build_box,"Scientific instrument",["Basic camera", "Advanced camera"])
    solar_selector = _selector(build_box,"Solar power",["Small array", "Large array"])
    antenna_selector = _selector(build_box,"Communications",["Basic antenna", "High gain antenna"])
    rocket_selector = _selector(build_box,"Launch vehicle",["Scout launcher", "Atlas-class game launcher"])
    for option in [cam_selector, solar_selector, antenna_selector, rocket_selector]:
        option.item_selected.connect(_update_build_preview)
    _button(build_box,"CHECK DESIGN",_validate_design)
    _button(build_box,"LAUNCH MISSION",_start_launch)
    _button(build_box,"CLOSE BUILDER",func(): _set_phase("HANGAR"))
    report_panel = PanelContainer.new()
    report_panel.position = Vector2(405,150)
    report_panel.custom_minimum_size = Vector2(465,350)
    root.add_child(report_panel)
    var report_box := VBoxContainer.new()
    report_panel.add_child(report_box)
    var report_title := Label.new()
    report_title.name = "ReportText"
    report_title.custom_minimum_size = Vector2(450,250)
    report_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    report_box.add_child(report_title)
    _button(report_box,"RETRY MISSION",_restart_mission)

func _selector(parent: Node, label_text: String, items: Array) -> OptionButton:
    var label := Label.new()
    label.text = label_text
    parent.add_child(label)
    var dropdown := OptionButton.new()
    for item in items:
        dropdown.add_item(str(item))
    parent.add_child(dropdown)
    return dropdown

func _button(parent: Node, title: String, callback: Callable) -> Button:
    var b := Button.new()
    b.text = title
    b.custom_minimum_size = Vector2(280,38)
    parent.add_child(b)
    b.pressed.connect(callback)
    return b

func _reset_actions() -> void:
    for child in actions.get_children():
        child.queue_free()

func _set_phase(next: String) -> void:
    phase = next
    build_panel.visible = next == "BUILD"
    report_panel.visible = next == "REPORT"
    player.enabled = next == "HANGAR"
    player.visible = next == "HANGAR" or next == "BUILD"
    _reset_actions()
    match next:
        "HANGAR":
            title_label.text = "MISSION ARCHITECT  /  HANGAR"
            message_label.text = "WASD move  •  SHIFT sprint  •  SPACE jump  •  E near terminal to build"
            _button(actions,"OPEN SPACECRAFT BUILDER",func(): _set_phase("BUILD"))
            rocket.visible = true
            satellite.visible = false
            earth.visible = false
        "BUILD":
            title_label.text = "MISSION DESIGN  /  ENGINEERING"
            message_label.text = "Choose your components and satisfy the mission constraints."
            _update_build_preview(0)
        "LAUNCH":
            title_label.text = "LAUNCH SEQUENCE  /  SCOUT BASE"
            message_label.text = "Liftoff underway. Watch altitude and fuel."
        "ORBIT":
            title_label.text = "MISSION CONTROL  /  EARTH ORBIT"
            message_label.text = "A/D steer • W/S altitude • I toggle camera • T downlink during contact"
            _button(actions,"TOGGLE SCIENCE CAMERA [I]",_toggle_science)
            _button(actions,"TRANSMIT DATA [T]",_transmit)
            _button(actions,"END MISSION / DEBRIEF",_finish_mission)
        "REPORT":
            title_label.text = "MISSION DEBRIEF"
            message_label.text = "Analyze the outcome, adjust design and retry."

func _design() -> Dictionary:
    var c: Dictionary = CAMERA_DATA[cam_selector.selected]
    var s: Dictionary = SOLAR_DATA[solar_selector.selected]
    var a: Dictionary = ANTENNA_DATA[antenna_selector.selected]
    var r: Dictionary = ROCKET_DATA[rocket_selector.selected]
    var mass: float = 65.0 + c.mass + s.mass + a.mass
    var power: float = 30.0 + c.power + a.power
    var total_cost: float = 30.0 + c.cost + s.cost + a.cost + r.cost
    var issues: Array[String] = []
    if mass > r.capacity: issues.append("Payload exceeds rocket mass capacity")
    if power > s.power: issues.append("Solar power insufficient for full-time operations")
    if total_cost > BUDGET: issues.append("Mission exceeds budget")
    return {"mass":mass,"power":power,"available_power":s.power,"cost":total_cost,"capacity":r.capacity,"issues":issues, "camera":c,"solar":s,"antenna":a}

func _update_build_preview(_idx: int) -> void:
    if phase != "BUILD": return
    var d := _design()
    var issue_string := "READY TO LAUNCH" if d.issues.is_empty() else "\n".join(d.issues)
    stats_label.text = "MISSION: Earth Climate Sentinel\nMass: %.0f / %.0f kg\nPower: %.0f / %.0f W\nBudget: %.0f / %.0f M credits\n%s" % [d.mass,d.capacity,d.power,d.available_power,d.cost,BUDGET,issue_string]

func _validate_design() -> void:
    var d := _design()
    if d.issues.is_empty():
        message_label.text = "DESIGN VALIDATED! Press LAUNCH MISSION."
    else:
        message_label.text = "FIX DESIGN: " + "; ".join(d.issues)

func _start_launch() -> void:
    var d := _design()
    if not d.issues.is_empty():
        _validate_design()
        return
    launch_timer = 0.0
    rocket.visible = true
    player.visible = false
    player.enabled = false
    _set_phase("LAUNCH")

func _start_orbit() -> void:
    _set_phase("ORBIT")
    rocket.visible = false
    earth.visible = true
    satellite.visible = true
    satellite.position = Vector3(0,0,20)
    orbit_elapsed = 0.0
    orbit_angle = 0.0
    lateral_offset = 0.0
    altitude = ORBIT_TARGET
    fuel = 100.0
    battery = 100.0
    storage = 0.0
    delivered = 0.0
    mission_time = 0.0
    score = 0
    science_on = true
    failure_reason = ""
    deployed = true

func _toggle_science() -> void:
    science_on = not science_on
    message_label.text = "Science camera ON" if science_on else "Science camera OFF (power saving)"

func _transmit() -> void:
    if phase != "ORBIT": return
    if not ground_contact:
        message_label.text = "NO GROUND CONTACT. Wait for the next communication window."
        return
    var a: Dictionary = ANTENNA_DATA[antenna_selector.selected]
    var amount: float = min(storage, a.link * 2.0)
    storage -= amount
    delivered += amount
    message_label.text = "Downlinked %.1f GB. Total delivered: %.1f GB" % [amount,delivered]
    if delivered >= 18.0:
        _finish_mission()

func _finish_mission() -> void:
    if phase != "ORBIT": return
    var success := delivered >= 18.0 and battery > 0.0 and fuel > 0.0
    if not success and failure_reason == "":
        failure_reason = "Science delivery target not achieved yet."
    score = clampi(int(delivered * 3.0) + int(battery * 0.22) + int(fuel * 0.14) + (15 if success else 0),0,100)
    _set_phase("REPORT")
    var report: Label = report_panel.get_node("VBoxContainer/ReportText")
    report.text = "MISSION %s\n\nScore: %d / 100\nDelivered science: %.1f / 18 GB\nRemaining power: %.1f%%\nRemaining fuel: %.1f%%\nMission duration: %.1f min (game time)\n\n%s\n\nLesson: Hardware choices determine mass, electricity and communications. Orbit contact windows limit science delivery." % ["SUCCESS" if success else "INCOMPLETE",score,delivered,battery,fuel,mission_time/60.0,"All primary objectives achieved." if success else failure_reason]

func _restart_mission() -> void:
    rocket.position = Vector3(10,0.3,-9)
    player.position = Vector3(-6,0,3)
    player.velocity = Vector3.ZERO
    _set_phase("HANGAR")

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo: return
    if phase == "HANGAR" and event.keycode == KEY_E:
        if player.global_position.distance_to(terminal.global_position) < 5.0:
            _set_phase("BUILD")
        else:
            message_label.text = "Move closer to the blue engineering terminal."
    elif phase == "ORBIT":
        if event.keycode == KEY_I: _toggle_science()
        elif event.keycode == KEY_T: _transmit()

func _process(delta: float) -> void:
    match phase:
        "HANGAR", "BUILD":
            camera.position = camera.position.lerp(player.position + Vector3(0,5.5,10),min(1.0,delta*5.0))
            camera.look_at(player.position + Vector3(0,1.5,0),Vector3.UP)
            if phase == "HANGAR":
                stats_label.text = "MISSION: Earth Climate Sentinel\nOBJECTIVE: Design, launch and deliver 18 GB\nMove to cyan terminal and press E.\nWalk around the 3D hangar."
        "LAUNCH":
            launch_timer += delta
            rocket.position.y = 0.3 + launch_timer * launch_timer * 2.2
            camera.position = rocket.position + Vector3(13,7,20)
            camera.look_at(rocket.position + Vector3(0,3,0),Vector3.UP)
            stats_label.text = "ALTITUDE: %.0f km (cinematic scale)\nENGINE: NOMINAL\nFLIGHT: %.1f / 9 seconds" % [launch_timer*60.0,launch_timer]
            if launch_timer >= 9.0:
                _start_orbit()
        "ORBIT":
            _tick_orbit(delta)

func _tick_orbit(delta: float) -> void:
    orbit_elapsed += delta
    mission_time += delta*60.0
    var altitude_input := 0.0
    if Input.is_key_pressed(KEY_W): altitude_input += 1.0
    if Input.is_key_pressed(KEY_S): altitude_input -= 1.0
    var steering := 0.0
    if Input.is_key_pressed(KEY_A): steering -= 1.0
    if Input.is_key_pressed(KEY_D): steering += 1.0
    if (altitude_input != 0.0 or steering != 0.0) and fuel > 0.0:
        altitude = clampf(altitude + altitude_input*10.0*delta,450.0,700.0)
        lateral_offset = clampf(lateral_offset + steering*delta*1.2,-7.0,7.0)
        fuel = maxf(0.0, fuel - (absf(steering)+absf(altitude_input))*delta*1.25)
    var period := TAU*sqrt(pow(EARTH_RADIUS+altitude,3.0)/MU_EARTH)
    orbit_angle += delta*TAU/55.0 # visual time acceleration
    sunlight = cos(orbit_angle) > -0.45
    ground_contact = sin(orbit_angle*2.0) > 0.60
    var d := _design()
    var c: Dictionary = d.camera
    var s: Dictionary = d.solar
    var a: Dictionary = d.antenna
    var generation: float = s.power if sunlight else 0.0
    var consumption: float = 30.0 + a.power + (c.power if science_on else 0.0)
    battery = clampf(battery + (generation-consumption)*delta/35.0,0.0,100.0)
    if battery <= 0.0:
        failure_reason = "Battery depleted: spacecraft entered safe mode."
        _finish_mission()
        return
    if science_on and storage < 40.0:
        storage = minf(40.0,storage + float(c.data)*delta*0.34)
    var rad := 20.0 + (altitude-550.0)/70.0
    satellite.position = Vector3(cos(orbit_angle)*rad,lateral_offset*0.4,sin(orbit_angle)*rad)
    satellite.rotate_y(delta*0.23)
    earth.rotation.y += delta*0.015
    camera.position = satellite.position + Vector3(3,5,10)
    camera.look_at(satellite.position,Vector3.UP)
    stats_label.text = "ALTITUDE: %.0f km | PERIOD: %.1f min\nFUEL: %.0f%% | BATTERY: %.0f%% | %s\nSCIENCE: %.1f GB stored | %.1f / 18 GB delivered\nGROUND CONTACT: %s | SCIENCE: %s\nTIME: %.1f min" % [altitude,period/60.0,fuel,battery,"SUNLIGHT" if sunlight else "ECLIPSE",storage,delivered,"YES - PRESS T" if ground_contact else "NO", "ON" if science_on else "OFF",mission_time/60.0]

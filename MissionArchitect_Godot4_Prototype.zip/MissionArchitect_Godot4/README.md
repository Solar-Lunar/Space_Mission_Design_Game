# Mission Architect: Beyond Earth — Godot 4 Prototype

A **playable starter vertical slice** for a NASA Space Apps-style 3D mission design adventure. Created as an original learning prototype, not an official NASA game.

## Start (Windows)

1. Download and unzip this project.
2. Install Godot 4.x (standard build) from https://godotengine.org/download/windows/ .
3. In Godot Project Manager select **Import**, choose `project.godot`.
4. Open project, press **F6/F5** (F5 to play the main scene).
5. Recommended: 1280x720 desktop window. All graphics are procedurally generated; no downloads or API keys required.

## Play controls

- **Hangar**: WASD move; Shift sprint; Space jump; E near blue terminal to build (or use the Open Builder button).
- **Builder**: Choose camera, solar array, antenna, launch vehicle. Check engineering issues. Launch only if mass, power and budget pass.
- **Launch**: Watch a short gamified cinematic launch sequence.
- **Orbit**: A/D steer spacecraft laterally; W/S adjust altitude (uses fuel); I toggle science collection; T transmit stored data when ground contact = YES.
- **Goal**: Deliver 18 GB of observations without running out of energy. Then mission debrief appears. Retry and make better choices.

## Simulation scope and scientific integrity

- Circular orbit period uses `T=2π sqrt((R+h)^3 / μ)` with Earth radius 6371 km and μ=398600.4418 km³/s².
- Orbital movement is *time-accelerated and visually scaled*. Orbit position, rocket ascent, ground contact, resource generation and camera science rates are simplified for gameplay.
- Rocket names, mass/cost/power budgets, science data rates and success scoring are **fictional game-balancing specifications**, not NASA flight hardware data.
- Solar availability and ground contact use periodic approximations, not orbital shadow geometry or antenna link-budget computations.
- Full launch aerodynamics, realistic 6-DOF flight, thermal dynamics, real NASA spacecraft specs, multiplayer and saving are NOT included in this prototype.
- No external NASA imagery is bundled; credit verified sources before adding assets.

## File layout

- `scenes/main.tscn` — main game scene
- `scripts/game.gd` — phase machine, world generation, UI, engineering & orbital loop
- `scripts/player.gd` — third-person astronaut movement and simple procedural model
- `docs/GDD.md` — full design document
- `docs/TASKS.md` — production roadmap and acceptance tests

## Developer notes

This is a starter implementation prepared without access to a running Godot editor in the creation environment. Scripts are designed for Godot 4.x, but **they have not been executed in the engine**. If Godot reports a parser issue, use the editor's error line and correct it before continuing. Priority next steps: source-controlled tests, gamepad camera, three-dimensional orbit planning, data-oriented equipment catalog, proper HUD/UX, sound, scene transitions.
